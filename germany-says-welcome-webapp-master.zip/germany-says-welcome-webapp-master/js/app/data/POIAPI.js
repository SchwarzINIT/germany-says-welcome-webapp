define({
    poiurl: "http://gsw.pajowu.de/api/poi/",
    categoryurl: "http://gsw.pajowu.de/api/poicategories/",
    tilelayer: 'http://{s}.osm.germany-says-welcome.de/osm/{z}/{x}/{y}.png'
});
