define({
    emergencyurl: "http://gsw.pajowu.de/api/emergencynumbers/"
});
