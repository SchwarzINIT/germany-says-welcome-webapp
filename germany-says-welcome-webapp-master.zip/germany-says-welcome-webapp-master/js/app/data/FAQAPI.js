define({
    faqurl: "http://gsw.pajowu.de/api/faq/",
    categoryurl: "http://gsw.pajowu.de/api/faqcategories/"
});
