define({
    phraseurl: "http://gsw.pajowu.de/api/phrasebook/",
    categoryurl: "http://gsw.pajowu.de/api/phrasecategories/"
});
