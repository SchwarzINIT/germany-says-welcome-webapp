define({
    statusValues: ['arrival', 'application', 'integration']
});
